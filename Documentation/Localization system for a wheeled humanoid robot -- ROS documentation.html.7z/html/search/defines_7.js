var searchData=
[
  ['vs',['VS',['../rollo_8hpp.html#ac896c73a5d99e82b2050d5f3d394e009',1,'rollo.hpp']]]
];
