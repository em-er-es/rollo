var searchData=
[
  ['rollo_5faxle_5fl',['ROLLO_AXLE_L',['../rollo_8hpp.html#adda3c5b201133986d89a5754a0464614',1,'rollo.hpp']]],
  ['rollo_5fspeed_5fmax',['ROLLO_SPEED_MAX',['../rollo_8hpp.html#a114b750e8b7e603ab4e1ec86c17d91ae',1,'rollo.hpp']]],
  ['rollo_5fspeed_5fmin',['ROLLO_SPEED_MIN',['../rollo_8hpp.html#aaf870ca6d958bdcc15e02b75044313b2',1,'rollo.hpp']]],
  ['rollo_5fwheel_5fn',['ROLLO_WHEEL_N',['../rollo_8hpp.html#a006539c07ac232a7e8c168942baee906',1,'rollo.hpp']]],
  ['rollo_5fwheel_5fradius_5fl',['ROLLO_WHEEL_RADIUS_L',['../rollo_8hpp.html#a6154ef87dd942cfe39c30fe19fdc56b2',1,'rollo.hpp']]],
  ['rollo_5fwheel_5fradius_5fr',['ROLLO_WHEEL_RADIUS_R',['../rollo_8hpp.html#a8bcac3e9878a4fe5451a9ee996022c3e',1,'rollo.hpp']]]
];
