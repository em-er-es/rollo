var searchData=
[
  ['kbhit',['kbhit',['../rollo__control_8cpp.html#a97e9b1fe8d4c010474637a654aad6566',1,'rollo_control.cpp']]],
  ['kf',['KF',['../rollo_8hpp.html#a88d70c2c026b9cb514de366a7b20ef8e',1,'rollo.hpp']]]
];
