var searchData=
[
  ['package',['PACKAGE',['../rollo_8hpp.html#aca8570fb706c81df371b7f9bc454ae03',1,'rollo.hpp']]],
  ['pi',['PI',['../rollo_8hpp.html#a598a3330b3c21701223ee0ca14316eca',1,'rollo.hpp']]],
  ['pp',['PP',['../rollo_8hpp.html#a15c8252e6b507e98f2814383ca4872a1',1,'rollo.hpp']]]
];
