var searchData=
[
  ['decodekey',['decodeKey',['../rollo__control_8cpp.html#af80674d90dd689526cf57e75f7432d08',1,'rollo_control.cpp']]],
  ['decodevelocities',['decodeVelocities',['../rollo__comm_8cpp.html#ae08ba04eb54f1f3f17f135034452e92c',1,'rollo_comm.cpp']]]
];
