var searchData=
[
  ['estimatefeedbackvelocities',['EstimateFeedbackVelocities',['../rollo__comm_8cpp.html#af756e338ef4741c56e65779cad33d03d',1,'rollo_comm.cpp']]]
];
