var searchData=
[
  ['timed_5frecv',['timed_recv',['../classudp__client__server_1_1udp__server.html#af376121a83f6c07187f077bc77aa6e27',1,'udp_client_server::udp_server']]]
];
