var searchData=
[
  ['get_5faddr',['get_addr',['../classudp__client__server_1_1udp__client.html#a1fbf29e1facd0a802a5032aa0273af63',1,'udp_client_server::udp_client::get_addr()'],['../classudp__client__server_1_1udp__server.html#a9b82191caf4ccc1d6822d5f92e382e02',1,'udp_client_server::udp_server::get_addr()']]],
  ['get_5fport',['get_port',['../classudp__client__server_1_1udp__client.html#ab4d8fc06bab9b1ab1435fa9d9a7bd9f8',1,'udp_client_server::udp_client::get_port()'],['../classudp__client__server_1_1udp__server.html#a78b6867c5dc04599c8b146fe4971459a',1,'udp_client_server::udp_server::get_port()']]],
  ['get_5fsocket',['get_socket',['../classudp__client__server_1_1udp__client.html#adb58b691a3fb90f86d6643e01123d528',1,'udp_client_server::udp_client::get_socket()'],['../classudp__client__server_1_1udp__server.html#ace51743964b568c021b0f3154f4c0306',1,'udp_client_server::udp_server::get_socket()']]]
];
