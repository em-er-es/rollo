var searchData=
[
  ['_7eudp_5fclient',['~udp_client',['../classudp__client__server_1_1udp__client.html#a2d86924b0df64eaa14db80ece0ab7812',1,'udp_client_server::udp_client']]],
  ['_7eudp_5fserver',['~udp_server',['../classudp__client__server_1_1udp__server.html#acdce04ccdcc420d4f959110c75ec9b1c',1,'udp_client_server::udp_server']]]
];
